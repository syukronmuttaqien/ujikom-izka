<?php $this->load->view('/master/navauth') ?>
    <div class="container">

      <form method="POST" action="<?=base_url('/Welcome/prosBook')?>" >
        <div class="row">
        <div class="col-md-12">
        <div class="card mb-3 text center">
        <img src="https://atpetsi.or.id/uploads/article/view/210507061237200228114324hotel.jpg" class="card-img-top" alt="" style="max-height: 400px;object-fit: cover;">
        <div class="card-body">
        <h5 class="card-title">Hotel Hebat</h5>
        <p class="card-text">Selamat Datang Di Hotel Hebat Kami Menyambutmu dengan Hangat</p>
        </div>
        </div>
        </div>
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-4">

        <p class="mb01">tgl_cekin</p>
        <input class="form-control" type="date" name="tgl_cekin" placeholder="tgl_cekin">
                  
                  </div>
                  <div class="col-md-4">

        <p class="mb01">tgl_cekout</p>
        <input class="form-control" type="date" name="tgl_cekout" placeholder="tgl_cekout">
        
                  </div>
              <div class="col-md-4">
                
        <p class="mb01">jml_kamar</p>
        <input class="form-control" type="number" name="jml_kamar" placeholder="jml_kamar">

              </div>
            </div>
          </div>
          <div class="col-md-12 mt-5">
            <h4>Form Pemesanan</h4>
          </div>
          <div class="col-md-12">

        <p class="mt-3">nama_pemesan</p> 
        <input class="form-control" type="text" name="nama_pemesan" placeholder="nama_pemesan" value="" >
        <p class="mt-3">email</p>
        <input class="form-control" type="email" name="email" placeholder="email">
        <p class="mt-3">no_hp</p>
        <input class="form-control" type="number" name="no_hp" placeholder="no_hp" value="">
        <p class="mt-3">Pilih Kamar</p>
        <select class="form-select" name="id_kamar">
        <?php foreach($data['alltipe'] as $key => $item): ?>
        <option><?=$item->Nama_room?></option>
        <?php endforeach; ?>
        </select>

        <p class="mt-3">PayBay</p>
        <select class="form-select" name="PayBay">
        <option>Bayar Ditempat</option>
        <option>Transfer Bank</option>
        </select>

        </div>

        <button type="submit">Kirim</button>

      </form>
    </div>
