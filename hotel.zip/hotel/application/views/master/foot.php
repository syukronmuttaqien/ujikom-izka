            </section>
          </div>
        </div>
        <footer>
          <div class="container">
            <div class="footer clearfix mb-0 text-muted">
              <div class="float-start">
                <p>2021 &copy; Mazer</p>
              </div>
              <div class="float-end">
                <p>Crafted with <span class="text-primary">
                  <i class="bi bi-star"></i>
                    </span>Izka
                    <span class="text-primary">
                  <i class="bi bi-star"></i>
                </p>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
    <script src="<?=base_url('/dist/')?>assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="<?=base_url('/dist/')?>assets/js/bootstrap.bundle.min.js"></script>
    <script src="<?=base_url('/dist/')?>assets/vendors/apexcharts/apexcharts.js"></script>
    <script src="<?=base_url('/dist/')?>assets/js/pages/dashboard.js"></script>
    <script src="<?=base_url('/dist/')?>assets/js/pages/horizontal-layout.js"></script>
  </body>
</html>