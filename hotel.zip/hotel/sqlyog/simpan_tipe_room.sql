DELIMITER $$

CREATE
    /*[DEFINER = { user | CURRENT_USER }]*/
    PROCEDURE `ci_db_hotel`.`simpan_tipe_room`(
    id INT(11),
    Nama_room VARCHAR(244),
    harga INT(11),
    Stok INT(11),
    onuse INT(11),
    onbook INT(11),
    img_room VARCHAR(255)
    )
    /*LANGUAGE SQL
    | [NOT] DETERMINISTIC
    | { CONTAINS SQL | NO SQL | READS SQL DATA | MODIFIES SQL DATA }
    | SQL SECURITY { DEFINER | INVOKER }
    | COMMENT 'string'*/
    BEGIN
	INSERT INTO tipe_room
	VALUES (id,Nama_room,harga,Stok,onuse,onbook,img_room);
    END$$

DELIMITER ;