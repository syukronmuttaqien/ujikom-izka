DELIMITER $$

CREATE
    /*[DEFINER = { user | CURRENT_USER }]*/
    PROCEDURE `ci_db_hotel`.`simpan_f_hotel`(
	id INT(11),
	nama_fasilitas VARCHAR(255),
	img VARCHAR(255),
	deks VARCHAR(255)
    )
    /*LANGUAGE SQL
    | [NOT] DETERMINISTIC
    | { CONTAINS SQL | NO SQL | READS SQL DATA | MODIFIES SQL DATA }
    | SQL SECURITY { DEFINER | INVOKER }
    | COMMENT 'string'*/
    BEGIN
	INSERT INTO f_hotel
	VALUES (id,nama_fasilitas,img,deks);
    END$$

DELIMITER ;