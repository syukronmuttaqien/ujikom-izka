DELIMITER $$

CREATE
    /*[DEFINER = { user | CURRENT_USER }]*/
    PROCEDURE `ci_db_hotel`.`simpan_pemesanan`(
	id_pesanan INT(11),
	nama_pemesan VARCHAR(50),
	email VARCHAR(35),
	no_hp VARCHAR(35),
	nama_tamu VARCHAR(50),
	id_kamar INT(11),
	tgl_cekin DATE,
	tgl_cekout DATE,
	jml_kamar INT(11),
	Harga INT(11),
	PayBay VARCHAR(244),
	PayEnd INT(1),
	Status_Kamar VARCHAR(255),
	RefPB VARCHAR(255)
	
    )
    /*LANGUAGE SQL
    | [NOT] DETERMINISTIC
    | { CONTAINS SQL | NO SQL | READS SQL DATA | MODIFIES SQL DATA }
    | SQL SECURITY { DEFINER | INVOKER }
    | COMMENT 'string'*/
    BEGIN
	INSERT INTO pemesanan
	VALUES (id_pesanan,nama_pemesan, email,no_hp,nama_tamu,tgl_cekin,tgl_cekout,jml_kamar,Harga,PayBay,PayEnd,Status_Kamar,RefPB);
    END$$

DELIMITER ;