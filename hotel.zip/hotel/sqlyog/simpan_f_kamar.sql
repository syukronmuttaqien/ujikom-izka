DELIMITER $$

CREATE
    /*[DEFINER = { user | CURRENT_USER }]*/
    PROCEDURE `ci_db_hotel`.`simpan_f_kamar`(
	id INT(11),
	id_tipekamar INT(3),
	nama_fasilitas VARCHAR(255),
	kategory VARCHAR(255),
	img VARCHAR(255)
	
    )
    /*LANGUAGE SQL
    | [NOT] DETERMINISTIC
    | { CONTAINS SQL | NO SQL | READS SQL DATA | MODIFIES SQL DATA }
    | SQL SECURITY { DEFINER | INVOKER }
    | COMMENT 'string'*/
    BEGIN
	INSERT INTO f_kamar
	VALUES (id,id_tipekamar,nama_fasilitas,kategory,img);
    END$$

DELIMITER ;