-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 16 Bulan Mei 2022 pada 08.52
-- Versi server: 10.4.17-MariaDB
-- Versi PHP: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ci_db`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_log`
--

CREATE TABLE `data_log` (
  `id` int(11) NOT NULL,
  `data` longtext DEFAULT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `data_log`
--

INSERT INTO `data_log` (`id`, `data`, `time`) VALUES
(1, '{\"get\":{\"data\":\"izka\"},\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-14 15:21:26'),
(2, '{\"get\":{\"data\":\"izka\"},\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-14 15:28:37'),
(3, '{\"get\":{\"data\":\"izka\"},\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-14 15:28:37'),
(4, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-14 15:29:29'),
(5, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/welcome\\/now\",\"get\":[],\"post\":{\"tgl_cekin\":\"2022-05-13\",\"tgl_cekout\":\"2022-05-16\",\"jml_kamar\":\"1\",\"nama_pemesan\":\"bubu\",\"email\":\"bubu@gmail.com\",\"no_hp\":\"2989147893739\",\"id_kamar\":\"VIP\",\"PayBay\":\"Bayar Ditempat\"},\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-14 15:30:07'),
(6, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":{\"t\":\"f_hotel\",\"v\":\"allcounter\"},\"post\":[],\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-14 15:45:49'),
(7, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Admin\\/data?t=f_hotel&v=allcounter\",\"get\":{\"v\":\"add\",\"t\":\"f_hotel\"},\"post\":[],\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-14 15:46:01'),
(8, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Admin\\/data?t=f_hotel&v=allcounter\",\"get\":{\"v\":\"add\",\"t\":\"f_hotel\"},\"post\":[],\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-14 15:46:17'),
(9, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":{\"t\":\"f_hotel\",\"v\":\"allcounter\"},\"post\":[],\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-14 15:46:18'),
(10, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 12:25:25'),
(11, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 12:27:39'),
(12, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/ref\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 12:27:50'),
(13, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":{\"id\":\"1\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 12:28:32'),
(14, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/detailTipe?id=1\",\"get\":{\"id\":\"1\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 12:28:35'),
(15, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/booknow?id=1\",\"get\":[],\"post\":{\"tgl_cekin\":\"2022-05-15\",\"tgl_cekout\":\"2022-05-16\",\"jml_kamar\":\"1\",\"nama_pemesan\":\"Izka Zakiyyatun Noer\",\"email\":\"gedyguyg@gmail.com\",\"no_hp\":\"089765436782\",\"nama_tamu\":\"jejeeew\",\"id_kamar\":\"1\",\"PayBay\":\"Bayar Ditempat\"},\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 12:29:00'),
(16, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/booknow?id=1\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 12:29:00'),
(17, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/booknow?id=1\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 12:29:21'),
(18, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 12:30:45'),
(19, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 12:31:03'),
(20, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05152215Bayar Ditempat142900\"},\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 12:31:09'),
(21, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/ref\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 12:39:12'),
(22, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 12:39:14'),
(23, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 12:39:15'),
(24, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 12:39:19'),
(25, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":{\"id\":\"1\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 12:39:25'),
(26, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/detailTipe?id=1\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 12:39:32'),
(27, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/detailTipe?id=1\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 13:05:33'),
(28, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/detailTipe?id=1\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 13:53:19'),
(29, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/detailTipe?id=1\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 14:47:07'),
(30, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 14:47:29'),
(31, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":{\"id\":\"1\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 14:48:36'),
(32, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/detailTipe?id=1\",\"get\":{\"id\":\"1\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 14:48:40'),
(33, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":{\"id\":\"1\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 14:48:59'),
(34, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":{\"id\":\"1\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 14:50:58'),
(35, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/detailTipe?id=1\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 14:51:14'),
(36, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 14:52:03'),
(37, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 14:52:06'),
(38, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 14:52:13'),
(39, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 14:52:21'),
(40, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05152215Bayar Ditempat142900\"},\"post\":[]}', '2022-05-15 14:57:12'),
(41, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 15:08:38'),
(42, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 15:08:59'),
(43, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 15:13:27'),
(44, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 15:13:34'),
(45, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05152215Bayar Ditempat142900\"},\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 15:13:43'),
(46, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 15:19:50'),
(47, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 15:29:26'),
(48, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 15:29:28'),
(49, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 15:29:29'),
(50, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 15:29:46'),
(51, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 15:29:50'),
(52, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 15:30:27'),
(53, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/ref\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 15:30:32'),
(54, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 15:30:38'),
(55, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 15:30:46'),
(56, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05152215Bayar Ditempat142900\"},\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 15:30:52'),
(57, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 15:59:49'),
(58, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 15:59:49'),
(59, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:08:20'),
(60, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/ref\",\"get\":{\"id\":\"36\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:09:07'),
(61, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/ref\",\"get\":{\"id\":\"36\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:10:17'),
(62, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 16:13:57'),
(63, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:14:12'),
(64, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:15:20'),
(65, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:19:05'),
(66, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:22:52'),
(67, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:23:13'),
(68, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/tamu\\/TipeKamar\",\"get\":{\"id\":\"1\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:23:21'),
(69, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/detailTipe?id=1\",\"get\":{\"id\":\"1\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:23:25'),
(70, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/booknow?id=1\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:23:33'),
(71, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/booknow?id=1\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:23:41'),
(72, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05152215Bayar Ditempat142900\"},\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 16:28:53'),
(73, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/booknow?id=1\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:28:59'),
(74, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/booknow?id=1\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:29:06'),
(75, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/ref\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:29:09'),
(76, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":{\"id\":\"1\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:29:17'),
(77, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/ref\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:29:22'),
(78, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:29:43'),
(79, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":{\"req\":\"Booked\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:29:49'),
(80, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:29:54'),
(81, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:30:03'),
(82, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:31:55'),
(83, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:32:17'),
(84, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:45:04'),
(85, '{\"get\":{\"req\":\"izka pacar jeje\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:45:34'),
(86, '{\"get\":{\"req\":\"izka pacar jeje\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:56:53'),
(87, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar?req=izka%20pacar%20jeje\",\"get\":{\"req\":\"Booked\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:57:01'),
(88, '{\"get\":{\"req\":\"izka pacar jeje\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:57:04'),
(89, '{\"get\":{\"id\":\"1\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 16:58:34'),
(90, '{\"get\":{\"req\":\"izka pacar jeje\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 17:01:19'),
(91, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar?req=izka%20pacar%20jeje\",\"get\":{\"id\":\"1\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 17:01:25'),
(92, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/detailTipe?id=1\",\"get\":{\"req\":\"Booked\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 17:02:10'),
(93, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/detailTipe?id=1\",\"get\":{\"req\":\"Booked\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 17:03:01'),
(94, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/detailTipe?id=1\",\"get\":{\"req\":\"Booked\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 17:03:46'),
(95, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/detailTipe?id=1\",\"get\":{\"req\":\"Booked\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 17:09:02'),
(96, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/tamu\\/ref?req=Booked\",\"get\":{\"req\":\"Tipe Kamar Pilihanmu\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 17:09:10'),
(97, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/tamu\\/TipeKamar?req=Tipe%20Kamar%20Pilihanmu\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 17:09:15'),
(98, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":{\"req\":\"Booked\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 17:09:20'),
(99, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/tamu\\/ref?req=Booked\",\"get\":{\"id\":\"36\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 17:09:23'),
(100, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/tamu\\/TipeKamar?req=Tipe%20Kamar%20Pilihanmu\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 17:09:44'),
(101, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 17:09:59'),
(102, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":{\"req\":\"Booked\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 17:10:07'),
(103, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05152215Bayar Ditempat142900\"},\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 17:10:19'),
(104, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 17:12:31'),
(105, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05152215Bayar Ditempat142900\"},\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 17:12:34'),
(106, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05152215Bayar Ditempat142900\"},\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 17:13:07'),
(107, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":{\"t\":\"f_hotel\",\"v\":\"allcounter\"},\"post\":[],\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-15 17:15:05'),
(108, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":{\"t\":\"f_hotel\",\"v\":\"allcounter\"},\"post\":[],\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-15 17:15:36'),
(109, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":{\"t\":\"f_hotel\",\"v\":\"allcounter\"},\"post\":[],\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-15 17:15:41'),
(110, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":{\"t\":\"f_hotel\",\"v\":\"allcounter\"},\"post\":[],\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-15 17:16:11'),
(111, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":{\"t\":\"f_hotel\",\"v\":\"allcounter\"},\"post\":[],\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-15 17:16:26'),
(112, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":{\"t\":\"f_hotel\",\"v\":\"allcounter\"},\"post\":[],\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-15 17:16:30'),
(113, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":{\"t\":\"f_hotel\",\"v\":\"allcounter\"},\"post\":[],\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-15 17:16:34'),
(114, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":{\"t\":\"f_hotel\",\"v\":\"allcounter\"},\"post\":[],\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-15 17:16:38'),
(115, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":{\"t\":\"f_hotel\",\"v\":\"allcounter\"},\"post\":[],\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-15 17:17:48'),
(116, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":{\"t\":\"f_hotel\",\"v\":\"allcounter\"},\"post\":[],\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-15 17:17:53'),
(117, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Admin\\/data?t=f_hotel&v=allcounter\",\"get\":{\"link\":\"id\",\"val\":\"1\",\"t\":\"f_hotel\"},\"post\":{\"id\":\"1\",\"nama_fasilitas\":\"F1\",\"img\":\"http:\\/\\/localhost\\/phpmyadmin\\/themes\\/pmahomme\\/img\\/logo_left.png\",\"deks\":\"tes\"},\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-15 17:18:00'),
(118, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Admin\\/data?t=f_hotel&v=allcounter\",\"get\":{\"t\":\"f_hotel\",\"v\":\"allcounter\"},\"post\":[],\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-15 17:18:01'),
(119, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Admin\\/data?t=f_hotel&v=allcounter\",\"get\":{\"link\":\"id\",\"val\":\"2\",\"t\":\"f_hotel\"},\"post\":{\"id\":\"2\",\"nama_fasilitas\":\"F2\",\"img\":\"https:\\/\\/atpetsi.or.id\\/uploads\\/article\\/view\\/210507061237200228114324hotel.jpg\",\"deks\":\"Nandeyo deyo\"},\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-15 17:18:10'),
(120, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Admin\\/data?t=f_hotel&v=allcounter\",\"get\":{\"t\":\"f_hotel\",\"v\":\"allcounter\"},\"post\":[],\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-15 17:18:10'),
(121, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Admin\\/data?t=f_hotel&v=allcounter\",\"get\":{\"t\":\"f_hotel\",\"v\":\"allcounter\"},\"post\":[],\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-15 17:18:49'),
(122, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Admin\\/data?t=f_hotel&v=allcounter\",\"get\":{\"t\":\"f_hotel\",\"v\":\"allcounter\"},\"post\":[],\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-15 17:20:32'),
(123, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Admin\\/data?t=f_hotel&v=allcounter\",\"get\":{\"t\":\"f_hotel\",\"v\":\"allcounter\"},\"post\":[],\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-15 17:20:36'),
(124, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Admin\\/data?t=f_hotel&v=allcounter\",\"get\":{\"t\":\"f_hotel\",\"v\":\"allcounter\"},\"post\":[],\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-15 17:20:50'),
(125, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/tamu\\/ref?req=Booked\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 17:21:51'),
(126, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Admin\\/data?t=f_hotel&v=allcounter\",\"get\":{\"t\":\"f_hotel\",\"v\":\"allcounter\"},\"post\":[],\"user\":{\"id_login\":\"7\",\"username\":\"chanie\",\"password\":\"12345678\",\"Nama\":\"Christoper Bahng\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"0000-00-00\",\"no_telp\":\"08665544387\",\"level\":\"admin\"}}', '2022-05-15 17:23:06'),
(127, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 17:29:13'),
(128, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 17:30:07'),
(129, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 17:34:04'),
(130, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 17:38:18'),
(131, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 17:38:28'),
(132, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 17:38:33'),
(133, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 17:38:38'),
(134, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 17:38:50'),
(135, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 17:39:28'),
(136, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/tamu\\/ref?req=Booked\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 17:39:29'),
(137, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 17:39:35'),
(138, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05152215Bayar Ditempat142900\"},\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 17:39:49'),
(139, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 17:39:54'),
(140, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-15 17:44:13'),
(141, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 17:51:03'),
(142, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-15 17:51:15'),
(143, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 02:49:04'),
(144, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":{\"id\":\"1\"},\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 02:49:17');
INSERT INTO `data_log` (`id`, `data`, `time`) VALUES
(145, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/detailTipe?id=1\",\"get\":{\"id\":\"1\"},\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 02:49:25'),
(146, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/booknow?id=1\",\"get\":{\"req\":\"Booked\"},\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 02:49:31'),
(147, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-16 02:52:30'),
(148, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-16 02:52:37'),
(149, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/login\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-16 02:53:03'),
(150, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05122212Bayar Ditempat090351\"},\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-16 02:53:07'),
(151, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05122212Bayar Ditempat090351\"},\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-16 02:54:50'),
(152, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05122212Bayar Ditempat090351\"},\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-16 02:54:53'),
(153, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/booknow?id=1\",\"get\":{\"req\":\"Booked\"},\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:08:34'),
(154, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/tamu\\/ref?req=Booked\",\"get\":{\"id\":\"25\"},\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:08:40'),
(155, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/detailTipe?id=1\",\"get\":{\"id\":\"1\"},\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:08:48'),
(156, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/booknow?id=1\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:08:58'),
(157, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:09:22'),
(158, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:11:41'),
(159, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:15:25'),
(160, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:15:48'),
(161, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Welcome\\/\",\"get\":{\"req\":\"Tipe Kamar Pilihanmu\"},\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:15:56'),
(162, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/tamu\\/TipeKamar?req=Tipe%20Kamar%20Pilihanmu\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:15:58'),
(163, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:16:01'),
(164, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:16:20'),
(165, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:16:28'),
(166, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:16:32'),
(167, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Welcome\\/\",\"get\":{\"req\":\"Tipe Kamar Pilihanmu\"},\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:17:16'),
(168, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Welcome\\/\",\"get\":{\"req\":\"Tipe Kamar Pilihanmu\"},\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:17:21'),
(169, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:17:22'),
(170, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:17:54'),
(171, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:17:57'),
(172, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/welcome\\/now\",\"get\":[],\"post\":{\"tgl_cekin\":\"2022-05-16\",\"tgl_cekout\":\"2022-05-17\",\"jml_kamar\":\"1\",\"nama_pemesan\":\"bubu\",\"email\":\"bubu@gmail.com\",\"no_hp\":\"090921389498\",\"id_kamar\":\"VIP\",\"PayBay\":\"Bayar Ditempat\"},\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:19:13'),
(173, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:20:00'),
(174, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/Login\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-16 03:26:58'),
(175, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-16 03:27:02'),
(176, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-16 03:27:06'),
(177, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-16 03:27:08'),
(178, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":{\"req\":\"Tipe Kamar Pilihanmu\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-16 03:27:12'),
(179, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/tamu\\/TipeKamar?req=Tipe%20Kamar%20Pilihanmu\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-16 03:27:14'),
(180, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":{\"req\":\"Booked\"},\"post\":[],\"user\":{\"id_login\":\"16\",\"username\":\"Izka\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089765436782\",\"level\":\"tamu\"}}', '2022-05-16 03:27:15'),
(181, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:29:40'),
(182, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:29:57'),
(183, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:36:14'),
(184, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:36:32'),
(185, '{\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:36:42'),
(186, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":{\"req\":\"Booked\"},\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 03:36:56'),
(187, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Auth\\/Login\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-16 03:38:02'),
(188, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05122212Bayar Ditempat090351\"},\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-16 03:38:07'),
(189, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05122212Bayar Ditempat090351\"},\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-16 03:38:19'),
(190, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05122212Bayar Ditempat090351\"},\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-16 03:38:22'),
(191, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05122212Bayar Ditempat090351\"},\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-16 03:39:46'),
(192, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05122212Bayar Ditempat090351\"},\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-16 03:44:30'),
(193, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05122212Bayar Ditempat090351\"},\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-16 03:44:57'),
(194, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05122212Bayar Ditempat090351\"},\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-16 03:45:11'),
(195, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05122212Bayar Ditempat090351\"},\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-16 03:48:13'),
(196, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05122212Bayar Ditempat090351\"},\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-16 03:50:53'),
(197, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":{\"ref\":\"05122212Bayar Ditempat090351\"},\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-16 04:12:47'),
(198, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/DataTrack?ref=05122212Bayar+Ditempat090351\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-16 04:12:56'),
(199, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-16 04:13:00'),
(200, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-16 04:13:08'),
(201, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Resp\\/Datatrack\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"6\",\"username\":\"izkaa\",\"password\":\"12345678\",\"Nama\":\"Izka Zakiyyatun Noer\",\"Jenis_Kelamin\":\"Perempuan\",\"tgllahir\":\"2004-08-09\",\"no_telp\":\"089654748894\",\"level\":\"resepsionis\"}}', '2022-05-16 04:13:11'),
(202, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/Tamu\\/TipeKamar\",\"get\":{\"req\":\"Booked\"},\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 04:13:16'),
(203, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/tamu\\/ref?req=Booked\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 04:13:21'),
(204, '{\"comefrom\":\"http:\\/\\/localhost\\/hotel\\/tamu\\/ref?req=Booked\",\"get\":[],\"post\":[],\"user\":{\"id_login\":\"15\",\"username\":\"jeongin\",\"password\":\"12345678\",\"Nama\":\"Yang Jeongin\",\"Jenis_Kelamin\":\"Laki-Laki\",\"tgllahir\":\"2001-02-08\",\"no_telp\":\"0073243669\",\"level\":\"tamu\"}}', '2022-05-16 04:14:43');

-- --------------------------------------------------------

--
-- Struktur dari tabel `f_hotel`
--

CREATE TABLE `f_hotel` (
  `id` int(11) NOT NULL,
  `nama_fasilitas` text NOT NULL,
  `img` text NOT NULL,
  `deks` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `f_hotel`
--

INSERT INTO `f_hotel` (`id`, `nama_fasilitas`, `img`, `deks`) VALUES
(1, 'F1', 'http://localhost/phpmyadmin/themes/pmahomme/img/logo_left.png', 'tes'),
(2, 'F2', 'https://atpetsi.or.id/uploads/article/view/210507061237200228114324hotel.jpg', 'Nandeyo deyo');

-- --------------------------------------------------------

--
-- Struktur dari tabel `f_kamar`
--

CREATE TABLE `f_kamar` (
  `id` int(11) NOT NULL,
  `id_tipekamar` int(3) NOT NULL,
  `nama_fasilitas` text DEFAULT NULL,
  `kategory` varchar(255) DEFAULT NULL,
  `img` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `f_kamar`
--

INSERT INTO `f_kamar` (`id`, `id_tipekamar`, `nama_fasilitas`, `kategory`, `img`) VALUES
(1, 1, 'TV LED 360inc', 'Electronic', ''),
(2, 1, 'Sofa Biru', 'Aksesoris', ''),
(3, 1, 'Meja meeting', 'Aksesoris', ''),
(4, 1, 'Kasur Twince', 'Aksesoris', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemesanan`
--

CREATE TABLE `pemesanan` (
  `id_pesanan` int(11) NOT NULL,
  `nama_pemesan` varchar(50) NOT NULL,
  `email` varchar(35) NOT NULL,
  `no_hp` varchar(35) NOT NULL,
  `nama_tamu` varchar(50) NOT NULL,
  `id_kamar` int(11) NOT NULL,
  `tgl_cekin` date NOT NULL,
  `tgl_cekout` date NOT NULL,
  `jml_kamar` int(11) NOT NULL,
  `Harga` int(11) NOT NULL,
  `PayBay` varchar(244) NOT NULL,
  `PayEND` int(1) NOT NULL,
  `Status_Kamar` varchar(255) NOT NULL,
  `RefPB` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pemesanan`
--

INSERT INTO `pemesanan` (`id_pesanan`, `nama_pemesan`, `email`, `no_hp`, `nama_tamu`, `id_kamar`, `tgl_cekin`, `tgl_cekout`, `jml_kamar`, `Harga`, `PayBay`, `PayEND`, `Status_Kamar`, `RefPB`) VALUES
(9, 'Agustinus Yoube', 'admin@lms.com', '081221723872', 'Gariner', 1, '2022-02-02', '2022-02-04', 0, 0, 'Bayar Di Tempat', 1, 'Cekin', '020222XYEGA152113'),
(10, 'Agustinus Yoube', 'lagustinus211@gmail.com', '081221723872', 'Gariner,Suge', 1, '2022-02-02', '2022-02-03', 2, 20000, 'Bayar Di Tempat', 1, 'Cekin', '020222Q5R8n161514'),
(11, 'Agustinus Yoube', 'lagustinus211@gmail.com', '081221723872', 'agus,iksan', 1, '2022-02-04', '2022-02-06', 2, 20000, 'Bayar Di Tempat', 1, 'Cekin', '020422rvqT3075446'),
(12, 'Agustinus Yoube', 'lagustinus211@gmail.com', '081221723872', 'Gariner', 1, '2022-02-05', '2022-02-06', 1, 10000, 'Bayar Di Tempat', 0, '0', '020522UfPOX102400'),
(13, 'Agustinus Yoube', 'lagustinus211@gmail.com', '081221723872', 'Gariner', 1, '2022-02-05', '2022-02-06', 1, 10000, 'Bayar Di Tempat', 1, 'Cekin', '020522B0paw102401'),
(25, 'Yang Jeongin', 'gedyguyg@gmail.com', '0073243669', 'jejeeew', 1, '2022-05-12', '2022-05-03', 1, 3000000, 'Bayar Ditempat', 0, '', '05122212Bayar Ditempat090351'),
(32, 'Izka1', 'gedyguyg@gmail.com', '1334364572342', 'Izka1', 0, '2022-05-14', '2022-05-15', 1, 0, 'Bayar Ditempat', 0, '', '05142214Bayar Ditempat164901'),
(33, 'Izka1', 'gedyguyg@gmail.com', '1334364572342', 'Izka1', 0, '2022-05-14', '2022-05-15', 1, 0, 'Bayar Ditempat', 0, '', '05142214Bayar Ditempat164908'),
(34, 'Izka1', 'gedyguyg@gmail.com', '1334364572342', 'Izka1', 0, '2022-05-14', '2022-05-15', 1, 0, 'Bayar Ditempat', 0, '', '05142214Bayar Ditempat164923'),
(35, 'bubu', 'bubu@gmail.com', '2989147893739', 'bubu', 0, '2022-05-13', '2022-05-16', 1, 0, 'Bayar Ditempat', 0, '', '05142214Bayar Ditempat173007'),
(36, 'Izka Zakiyyatun Noer', 'gedyguyg@gmail.com', '089765436782', 'jejeeew', 1, '2022-05-15', '2022-05-16', 1, 3000000, 'Bayar Ditempat', 0, '', '05152215Bayar Ditempat142900'),
(37, 'bubu', 'bubu@gmail.com', '090921389498', 'bubu', 0, '2022-05-16', '2022-05-17', 1, 0, 'Bayar Ditempat', 0, '', '051622Bayar Ditempat051913');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tipe_room`
--

CREATE TABLE `tipe_room` (
  `id` int(11) NOT NULL,
  `Nama_room` varchar(244) NOT NULL,
  `harga` int(11) DEFAULT NULL,
  `Stok` int(11) NOT NULL,
  `onuse` int(11) NOT NULL,
  `onbook` int(11) NOT NULL,
  `img_room` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tipe_room`
--

INSERT INTO `tipe_room` (`id`, `Nama_room`, `harga`, `Stok`, `onuse`, `onbook`, `img_room`) VALUES
(1, 'VIP', 3000000, 12, 0, 0, 'https://asset.kompas.com/crops/33vZ6Rt128kzOfcC_aU3fy7oo0I=/0x36:640x463/750x500/data/photo/2020/07/10/5f081b41cc76c.jpeg'),
(2, 'Delux', 2000000, 10, 0, 0, 'https://arsitagx-master.s3.ap-southeast-1.amazonaws.com/img_large/1889/988/6193/photo-hotel-room-1-sultan-hotel-at-senayan-desain-arsitek-oleh-yaph-studio.jpeg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id_login` int(11) NOT NULL,
  `username` varchar(35) NOT NULL,
  `password` varchar(35) NOT NULL,
  `Nama` varchar(255) NOT NULL,
  `Jenis_Kelamin` varchar(255) NOT NULL,
  `tgllahir` date NOT NULL,
  `no_telp` varchar(14) NOT NULL,
  `level` enum('admin','resepsionis','tamu') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id_login`, `username`, `password`, `Nama`, `Jenis_Kelamin`, `tgllahir`, `no_telp`, `level`) VALUES
(6, 'izkaa', '12345678', 'Izka Zakiyyatun Noer', 'Perempuan', '2004-08-09', '089654748894', 'resepsionis'),
(7, 'chanie', '12345678', 'Christoper Bahng', 'Laki-Laki', '0000-00-00', '08665544387', 'admin'),
(15, 'jeongin', '12345678', 'Yang Jeongin', 'Laki-Laki', '2001-02-08', '0073243669', 'tamu'),
(16, 'Izka', '12345678', 'Izka Zakiyyatun Noer', 'Perempuan', '2004-08-09', '089765436782', 'tamu');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `data_log`
--
ALTER TABLE `data_log`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `f_hotel`
--
ALTER TABLE `f_hotel`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `f_kamar`
--
ALTER TABLE `f_kamar`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pemesanan`
--
ALTER TABLE `pemesanan`
  ADD PRIMARY KEY (`id_pesanan`),
  ADD KEY `id_kamar` (`id_kamar`);

--
-- Indeks untuk tabel `tipe_room`
--
ALTER TABLE `tipe_room`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_login`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `data_log`
--
ALTER TABLE `data_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=205;

--
-- AUTO_INCREMENT untuk tabel `f_hotel`
--
ALTER TABLE `f_hotel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `f_kamar`
--
ALTER TABLE `f_kamar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `pemesanan`
--
ALTER TABLE `pemesanan`
  MODIFY `id_pesanan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT untuk tabel `tipe_room`
--
ALTER TABLE `tipe_room`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id_login` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
